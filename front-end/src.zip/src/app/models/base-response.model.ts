export interface BaseResponse {
  success: boolean;
  message: string;
  data: any[] | Object | null;
}
